import axios from "axios";

class TicketService {
  getTickets() {
    return axios
      .get(`https://localhost:7017/api/Ticket/Reterive`)
      .then((response) => response.data)
      .catch((error) => {
        throw new Error(error);
      });
  }
}

export default TicketService;
